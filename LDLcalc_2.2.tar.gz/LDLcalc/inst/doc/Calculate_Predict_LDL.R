## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----functions----------------------------------------------------------------
library(LDLcalc)
ls("package:LDLcalc")


