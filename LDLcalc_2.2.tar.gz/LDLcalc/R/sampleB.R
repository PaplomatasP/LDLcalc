#'@title Anonymous real data
#'@description A data set of repeated measurements of cholesterol, LDL and triglycerides. It is used as data for the examples.
#'
#'@format A \code{data frame} with 10 elements, which are:
#'\describe{
#'\item{day}{Day number of each measurement}
#'\item{CHOLrep1, CHOLrep2, CHOL}{ Replicate measurements of cholesterol for each day and their mean.}
#'\item{HDLrep1, HDLrep2, HDL}{eplicate measurements of HDL for each day and their mean.}
#'\item{LDLrep1, LDLrep2, LDL}{ LDL calculated according to the Friedewald formula mentioned above and its mean. All measurement units are in mg/dl and not mmol/L.}
#'}
"sampleB"
