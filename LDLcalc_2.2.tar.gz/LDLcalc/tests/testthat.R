library(testthat)
library(LDLcalc)

test_check("LDLcalc")
